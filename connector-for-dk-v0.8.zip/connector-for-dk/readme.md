# Connector for dk

<img alt="" src="/assets/icon.svg" width="128" height="128" />

Sync your WooCommerce store with DK, including product prices, inventory status and generate invoices for customers on checkout.

This codebase originates as [an earlier work](https://github.com/1984hosting/1984-connector-for-dk-and-woocommerce), which is currently defunct. This should be considered to be a continuation of the that project by the same developer. This fork of the software is **not supported or endorsed by 1984 Hosting** and the continued development of this fork is done by Alda Vigdís Skarphéðinsdóttir. License codes are sold on [tengillpro.is](https://tengillpro.is).

> [!CAUTION]
> **Do not open an issue ticket if you are reporting a security vulnerability. Contact the author directly via aldavigdis@aldavigdis.is or the WordPress Security Team instead.**

> [!IMPORTANT]
> This is a code repository used for the *development* of **Connector for dk**, a WordPress plugin. To purchase a subscription or get more user-centric information, please visit [tengillpro.is](https://tengillpro.is/).

## Developer Documentation

Please note that there are two readme files — this one (reamde.md) and the user-facing readme ([readme.txt](readme.txt)) is used for providing metadata to the WordPress.org plugin repository as well as a general introduction to the plugin.

This file is mainly intended for development and contribution purposes.

### System Requirements

We use Github actions as a continious integration process to automatically test the plugin using the following PHP and WordPress versions:

* PHP 8.2 and above
* WordPress 6.8 and above

We generally assume that the most recent version of WooCommerce is in use and use that for testing across the supported PHP and WordPress versions. This is done using a test martrix in the Github CI process.

### Introduction and main concepts

In the most simple terms this WordPress plugin syncs information between a WooCommerce store and the DK accounting software. It syncs product data, creates invoices for fulfilled orders and sync stock levels for products between the two.

#### Two sources of truth

* The WooCommerce store is the source of truth for product prices and availability towards the customer
* The DK setup is the source of truth for accounting transactions

This means that any price calculations and display, including customer-specific discounts done within WordPress or WooCommerce, facilitated by this plugin and should not require querying the dkPlus API each time a product price is calculated or displayed.

While this does mean that prices only get updated on an hourly basis using wp-cron, it ensures that the product price displayed to the customer (shelf price) is the same as the ones that end up on the customer's invoice.

### Filters and actions

The plugin uses filters and actions for a many of the things that happen under the bonnet. They are not specifically documented here, but you can find them if you search the codebase for the `apply_filters` and `do_action` functions.

You can employ this in your own plugins or in a file that you upload to `mu-plugins`. It is considered good practice and far simpler to use mu-plugins for modifying specific behaviour like this than to make a full-on traditional WordPress plugin for this purpose.

#### Example filters

Any configuration setting can be modified on runtime using the `connector_for_dk_get_option_$option_name` filter. This can be useful if you need to prevent some changes from being made using the wp-admin interface.

If you would like to force the default SKU for product with 24% VAT to a certain value, you can do the following:

```php
<?php

add_filter(
	'connector_for_dk_get_option_sku_for_24_vat',
	function (): string {
		return '24vatsku';
	},
	10,
	0
);
```

You may want to limit some of the plugin's functionality in highly constrained and limited hosting environments or if your site is not performant enough to successfully run wp-cron jobs for any other reason. You can use filters is to scale down the number of products that get updated and created in WooCommerce from the default value of 64. (You can do this in the opposite direction if you have a super performant machine let the maximum execution time exceed the default 30 seconds.)

```php
<?php

add_filter(
	'connector_for_dk_update_current_quantity',
	function (): int {
		return 16;
	},
	10,
	0
);

add_filter(
	'connector_for_dk_new_products_quantity',
	function (): int {
		return 8;
	},
	10,
	0
);
```

### The DK API

#### The DK API documentation

The DK API documentation is well known for being inaccurate and it seems to be written by two separate developers in different places.

One version of it can be found at https://apidoc.dkplus.is/ and is generated using Postman.

The other version is generated using Swagger and is available at https://api.dkplus.is/swagger/ui/index.

Either version documents certain endpoints at different states. Some features are missing and some of the specifics described seem to be documented ahead of time and don't actually exsist (as they may only be working internally, with the public version trailing behind). There are also spelling errors and other discrepencies in some JSON properties that are not reflected in the documentation.

#### Caveats

DK will cut off some string values that exceed its limits without warning. This is not well documented by them.

* Product Codes (SKUs): The DK API is unable to accept longer values than 20 and it may not support non-alphanumeric symbols
* Product variation SKUs are supposed to be empty
* Product descriptions: The DK API is unable to accept longer textual values than 40.

### Language and Internationalisation

We use UK/GB spelling whenever possible. The plugin is mainy run using the `is_IS` locale and it is important that the wording used for both locales corresponds with both the grown-up version of DK and dkPlus.

POT and JSON files are generated using `cd wp-content/plugins/connector-for-dk && wp i18n make-pot . languages/connector-for-dk.pot --allow-root` from the Bash shell and then they get translated using the Loco Translate plugin.

### Command Line Tools

The following command line tools are available for development and release purposes:

#### Shells

* **`composer shell:bash`**: Open up a bash shell in the Dockpress development environment
* **`composer shell:wp`**: Opens up a WordPress psysh shell in the DockPress development environment

### Linting and Testing

* **`composer test`**: Run all the PHPUnit test
* **`composer lint`**: Lint the PHP and JavaScript code, without fixing
* **`composer lint:fix`**: Fix any linting errors in the code

#### Build and release

* **`composer release:zip` or `./bin/release-zip.sh`**: Create a zip file that is ready to be uploaded to a distribution repository or release management system
* **`composer checksums:generate` or `./bin/checksums-generate`**: Generate a file containing the checksums of all the files in the repository. (Please delete the `./vendor` directory and run `composer install --no-dev` first.)
* **`composer checksums:validate` or `./bin/checksums-validate`**: Validate the files in the repository against `checksums.txt`. (Note that `checksums.txt` itself will be listed as a stray file as it is not listed.)

## Contributing

The main code repository for the plugin is at https://github.com/aldavigdis/connector-for-dk-and-woocommerce/. The Subversion account for the WordPress plugin respository is used for "built" releases of the plugin.

If you are reporting a bug, please describe the steps needed to be taken so that we can replicate it, if possible.

And last but not least, be nice to the author and other contributors.

### Coding Style and Best Practices

A WPCS-based coding style is enforced using PHPCodeSniffer. We have done some modifications and exceptions that are documented in the `phpcs.xml` file.

Our coding style rules apply to PHP, CSS and JS files. Please make sure that your editor supports and respects `.editorconfig` and that it integrates with the version of PHPCodeSniffer that is installed by Composer, in our `vendor` directory.

We also use PHP Intelephense to enable autocompletion and syntax highlighting for WordPress and WooCommerce specific functions. Please facilitate it by using and defining object classes specific to your use case.

* We are PHP 8.2 compliant, use strict mode, type hinting, strong typing and PSR-4 autoloading via Imposter
* We use `BigDecimal` from [brick/math](https://github.com/brick/math) for any financial calculations, even basic arithmetic
* Due to the nature of WordPress' hooks, while the code is written in an object oriented style, classes are written using static functions to a large extent
* Functions, objects, variables etc. are named using Ruby conventions (i.e. snake case and no shorthand names)
* Please keep runtime code within the `src` directory and install external dependencies using Composer
* The linter rules enforce docblocks for PHP functions, methods, classes etc. using the same rules as in PSR-12
* We try to stay within a soft 80-character line limit if we can, but we will not enforce it until a 120-character limit
* Please run `composer lint` and `composer lint:fix` in order to check and fix your code before sending in a pull request
* Please make sure that the few tests that we have work by running `composer test`
* We do not have unit tests for everything, but we do appreciate them being written

We use a Github Actions based CI process to check if pull requests adhere to the enforced coding standards. Pull requests may be rejected, re-written or re-done from scratch if they do not adhere to the coding standards and modern industry best practices.

If you think your code warrants a modification to or exception from the PHPCodeSniffer rules, please let us know.

#### Views

The coding style for views and view partials, residing in the `views` directory varies a little bit from the rest of the codebase:

* Views use ["colon syntax"](https://www.php.net/manual/en/control-structures.alternative-syntax.php) for control structures
* No maximum line length is enforced for views to account for things such as long sentences within i18n functions, but please stay within sensible limits
* For block-level HTML elements, attributes and text nodes are to be indented and kept on separate lines in order to limit line lengths

## Contact

The main author can be contacted via aldavigdis@aldavigdis.is. She is available for hire, some of her previous work can be found at and she can be supported via Github Sponsors at https://github.com/sponsors/aldavigdis.

## License

This plugin is provided to you as free software under the GPLv3 license. Runtime dependencies are provided under the MIT and Apache licenses, which are compatible with the GPLv3.

Connector for dk

Copyright (C) 2024 Alda Vigdis and contributors - based on 1984 Connector for dk and WooCommerce

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.

