=== Connector for dk ===
Stable tag: 0.8
Contributors: @aldavigdis
Tags: WooCommerce, DK, dkPlus, Inventory, Invoicing
Requires at least: 6.9
Tested up to: 7.1
Requires PHP: 8.3
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Sync your WooCommerce store with DK, including product prices, inventory status and generate invoices for customers on checkout.

== About ==

Synchronise products, prices and inventory status between your WooCommerce store and your DK account. Have DK generate invoices automatically on checkout without worrying about setting up an email connection for your WordPress site.

Variant products, sale prices and stock quantity can be set to sync globally and on a per-product basis.

== Installation ==

You will need to finish setting up your WooCommerce shop, including tax rates, payment methods, whether prices are VAT-inclusive etc in accordance with how things are set up in your DK installation before you install, activate and configure the plugin.

In order to get started, you need to set up an account with DK's dkPlus web service:

Enter your dkPlus API key in the form provided for a user with sufficient privileges under *WooCommerce 🠆 Connector for dk*, correlate your WooCommerce Payment Gateways with the Payment Methods in your DK account and make sure that other settings are in accordance with how they are set up in DK.

Once a connection has been established, the plugin will work right away and will register products and other records in DK on creation in WooCommerce, as long as the correct inventory codes are set and a correct SKU is set for each item.

Always back up your accounting records, site data and disable any plugin that may be incompatible with Connector for dk.

== Screenshots ==

1. Products can be fetched from DK on an hourly basis. The kind of information fetched and updated from DK can also be fine-tuned. Pulling product information from DK can also be disabled completely if you have entered your products manually into WooCommerce, with a SKU matching the corresponding DK Item Code.
2. WooCommerce payment gateways can be matched to their respective counterparts in DK. Booking a payment automatically is also optional for each payment method.
3. Invoices can be automatically generated on checkout. The plugin offers a plethora of optional conditions for automatic invoice generation taking place.
4. If not automatically generated on checkout, invoices can be created with a single click from the Order Editor. If an invoice has been made manually in DK, it can still be assigned to the order and the same goes with credit invoices.
5. A placeholder kennitala for both domestic and international customers can be set and the plugin has a method to assign customer numbers to international customers.
6. The Product Variation Editor has been re-worked from scratch and adapted to support and facilitate DK product variations. Pricing and availability can be set on a per-variant basis.
7. Product sync can be adjusted on a per-product basis under its own tab in the Product Editor.

== Changelog ==
= 0.8 =
* Fixing a bug that prevented the settings form from being submitted

= 0.7.8 =
* Documentation changes
* Fixing Icelandic language strings
* Making API key input invisible until the input field is focused
* Changes to development tools

= 0.7.7 =
* Improving the handling of products with no or empty price attribute, improving stability overall

= 0.7.6 =
* Now updating products when settings are saved
* Improving error handling when the WooCommerce product lookup table is out of sync

= 0.7.5 =
* Optimising configuration value caching, reducing database load
* Caching the current customer object, reducing database load
* Skipping over trashed products when updating

= 0.7.4 =
* Overhauling SQL queries for product sync
* Improving sale and discount price display

= 0.7.3 =
* Fixing a bug that prevented before/after sale prices from displaying correctly

= 0.7.2 =
* Defining 7.0 as the target WordPress version
* Extending automatic invoice generation to cover 48 hours instead of the past 4 hours
* Adding support for logged-in users' default payment terms
* Various improvements for coding and CI processes

= 0.7.1 =
* Fixing a crash in the cart
* Fixing scaling issues by optimising database queries, so some actions take only a fraction of the time they took

= 0.7.0 =
* Displaying live import and deletion information with a progress bar on the admin page
* Removing the "import as draft" feature
* Changing the product update interval to 2 minutes from 5
* Improving support for product discounts
* Indicating support for WordPress 7.0
* Various bug fixes and minor improvements

= 0.6.9 =
* Introducing product quantity filters
* Enabling product deletion if non-web products are not fetched from dk

= 0.6.8 =
* Fixing product variation caching and sync issue
* Fixing how invoice numbers and errors are displayed in the WooCommerce order list
* Fixing type errors in product variation interface

= 0.6.7 =
* Cleaning up wp-cron jobs
* Hiding product categories/group UI from the admin page when not in use

= 0.6.6 =
* Making the use of "default SKUs" if a product SKU is not set optional

= 0.6.5.1 =
* Fixing Icelandic language strings

= 0.6.5 =
* Splitting the monolithic cron job into multiple smaller ones
* Optionally deferring invoice generation to a cron job

= 0.6.4.2 =
* Further improvements to caching strategy
* Further improvements to invoice generation and subtotal/total rounding

= 0.6.4.1 =
* Updating attribute caching strategy, making the UI more stable when the dkPlus API isn't responding and improving speed

= 0.6.4 =
* Revamping the customer discount system, which now works with blocks (FSE/Gutenberg)
* Fixing off-by-one errors for customers price groups
* Fixing email delivery for international orders

= 0.6.3 =
* Improving discount display for logged-in customers

= 0.6.2 =
* Removing the variation discount filter as it was causing discounts to be applied twice
* Rounding customer discounts for improved accuracy
* Tweaking attribute caching strategy

= 0.6.1 =
* Rounding imported product prices and discounted customers' prices

= 0.6.0 =
* Improving handling for slow dkPlus API response times
* Introducing product category sync
* Introducing per-refund credit invoices
* Labelling customer discounts as experimental
* Fixing a bug that caused customer discounts to be stacked

= 0.5.2 =
* Fixed 11% VAT matching for products without SKU

= 0.5.1 =
* Added rawurlencode to any dynamic URL API requests for improved safety
* Fixed a bug that prevented the sales person number from being updated
* Fixed a bug that prevented payment some gateways from showing up in the admin page
* Fixed a but that prevent customer contacts from being assigned to invoices
* Fixing discrepancy between license date display between backend and frontend

= 0.5 =
* A rebrand and re-namespacing of a new fork
* Moved per-product DK options into a separate tab in the Product Editor
* Fixed a bug that affected invoices for product variations with two attributes
* Improved error handling in invoice generation
* Improved variation display on the frontend
* Improved code for tax rate matching
* Improved the loading speed of the admin page tenfold by using transient values
* Added a readiness check to the admin page
* Made product sync optional
* Removed any upstream push for products
* Rearranged and adding new options to the admin page
* Products-as-variations should now be possible
* The kennitala field can now be made mandatory
* Improved support for international orders and customers
* Added support for per-customer price groups and discounts
* Improved the precision of imported product sales prices, rounding them down
* Introducing support for item discounts on invoices and in the Order Editor
* Products no longer need to be available in order for invoices to be generated
* Invoice generation is now limited to orders made with the plugin installed
* Enabling arbitrary configuration using PHP constants
* Improving PDF invoice retreival, enabling support for Chrome and Safari
* Improving arithmetic precision
* Adding vat-specific token product codes that are used when a product SKU is missing
* Improvements to the settings form
* Fixing textdomain issues
* Enabling coupon discounts
* Added support for customer contacts for registered customers (signed-in users)
* Added a licensing system
* Added updates via Github
* Improved the accuracy of VAT calculations
* Added Iceland to the WooCommerce list of countries that use VAT

== Frequently Asked Questions ==

= Does the plugin support per-customer discounts and price groups? =

Yes, the plugin fetches per-customer discounts from DK. However, this is only supported for registered users that have had the Kennitala field set to correspond with their Kennitala or Customer Number in DK.

Group pricing is currently not supported for variable products. If an item is on sale, the sale price take prominence over the customer discount and group price regardless of which is lower than the other.

= Is the plugin easy to use? =

Once the plugin has been set up, it integrates with WooCommerce and tries its best to stay out of sight. Setting it up however may require hand-holding from your accountant or finance manager.

= Does the plugin support WooCommerce coupons? =

WooCommerce coupons are turned off completely by the plugin as they are currently not supported and require substantial work in order to be integrated with how DK handles discounts. If you need coupon support or any new feature that is not supported, feel free to reach out to the author if you'd like sponsor the feature.

= Is data synchronisation fully bi-directional? =

The general rule is not to write or replace information in DK unless it's necessary. Besides new customer records and invoices, data is synced downstream (from DK to WooCommerce) only.

= Does the plugin handle assigning Kennitala to orders and customers? =

The plugin adds a kennitala field to the checkout page as well as as a field under each registered customer's billing information. This field is compatible with the Iceland Post plugin.

Kennitala entry is not checked for validity (including dates of birth and check digits) due to how DK handles them on their end and your customers may possibly enter typos and make other mistakes.

If the Kennitala field is disabled or a kennitala is not provided on checkout, invoices will be assigned to a ‘default kennitala’, symbolising an anonymous payment.

= Can my DK customer records be affected by the plugin? =

Customers providing a kennitala can optionally be registered as debtors/customers in your DK setup if they are not registered already. However, at this point customer records are not automatically updated based on information from WooCommerce. The plugin will however not overwrite or edit existing customer records in DK.

= Does the plugin support self-hosted DK? =

As the plugin uses the dkPlus API and dkPlus does not support self-hosted DK setups as far as we know, they are currently unsupported. (But do let us know if you find out that's not the case and we will be happy to work with you!)

= Do I need to set up email delivery for invoices? =

The plugin does not depend on WordPress or your web server being able to send emails. As we are leveraging DK’s own email functionality, you need to enter the correct settings into DK and set the appropriate DNS settings such as your domain's SPF record in order for invoice delivery to work.

= Does the plugin support the new block based WooCommerce Checkout form and Cart Page? =

Yes. The plugin supports both the "Classic" shortcode based Checkout and Cart forms as well as their Block Editor based counterparts. There is a lot of work that goes into having to do things twice over, but we this plugin is developed for both versions of the checkout process.

== Policies, Privacy and Legal ==

This plugin's functionality depends on connecting to the dkPlus API, provided by DK Hugbúnaður ehf (DK). DK provides its services as per [their own General Terms and Conditions](https://dk.kreatives.is/wp-content/uploads/2024/08/General_Terms_and_Conditions_1_2024.pdf) (PDF) and [Privacy Policy](https://www.dk.is/um-dk/stefnur-og-skilmalar/personuverndarstefna#nanarenglish) (PDF).

This plugin is developed, maintained and supported on goodwill basis, without any warranty or guarantees as per the GPLv3 license. As the plugin connects to, uses and affects live DK accounting data, it is highly recommended that all information in your DK accounting software is backed up and that your DK accounting records are monitored for any unexpected changes. Furthermore, it is higly recommended that you evaluate this plugin in a limited capacity in a staging environment before putting it to full use.

