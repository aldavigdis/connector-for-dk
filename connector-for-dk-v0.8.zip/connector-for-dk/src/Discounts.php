<?php

declare(strict_types = 1);

namespace AldaVigdis\ConnectorForDK;

use AldaVigdis\ConnectorForDK\Helpers\Product as ProductHelper;
use AldaVigdis\ConnectorForDK\Helpers\Customer as CustomerHelper;
use AldaVigdis\ConnectorForDK\Brick\Math\BigDecimal;
use WC_Customer;
use WC_Order_Item;
use WC_Order_Item_Product;
use WC_Product;
use WC_Product_Variable;
use WP_User;
use WC_Cart;
use WC_Order;
use WC_Order_Item_Coupon;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The Discount Class
 *
 * Ammends the default prices used by WooCommerce using the customer's dk
 * discount and price group, and facilitates the use of product discounts
 * from dk.
 *
 * If a price is based on a price group, the customer's discount gets applied.
 *
 * The product's sale price has prominence over the customer's price. This means
 * that if the customer's discounted price would be 1000 ISK but the sale price
 * is 2000 ISK, the sale price is still used. Discounts also do not compound
 * with sale prices.
 */
class Discounts {
	const INDICATOR_CSS_CLASSES = array(
		'connector-for-dk-discount',
		'has-font-size',
		'has-medium-font-size',
	);

	/**
	 * The constructor
	 */
	public function __construct() {
		add_filter(
			'woocommerce_get_price_html',
			array( __CLASS__, 'get_price_html' ),
			10,
			2
		);

		add_filter(
			'woocommerce_get_price_html',
			array( __CLASS__, 'add_quantity_discount_to_price_display' ),
			10,
			2
		);

		add_filter(
			'woocommerce_product_get_price',
			array( __CLASS__, 'price_to_customer_price' ),
			10,
			2
		);

		add_filter(
			'woocommerce_product_variation_get_price',
			array( __CLASS__, 'price_to_customer_price' ),
			10,
			2
		);

		add_filter(
			'woocommerce_product_get_regular_price',
			array( __CLASS__, 'regular_price_to_group_price' ),
			10,
			2
		);

		add_filter(
			'woocommerce_product_variation_get_regular_price',
			array( __CLASS__, 'regular_price_to_group_price' ),
			10,
			2
		);

		add_filter(
			'connector_for_dk_customer_price_format',
			array( __CLASS__, 'adapt_formatting_to_themes' ),
			10,
			1
		);

		add_filter(
			'woocommerce_cart_item_price',
			array( __CLASS__, 'filter_cart_item_price' ),
			10,
			2
		);

		add_filter(
			'woocommerce_cart_item_subtotal',
			array( __CLASS__, 'filter_cart_item_subtotal' ),
			10,
			2
		);

		add_filter(
			'woocommerce_order_formatted_line_subtotal',
			array( __CLASS__, 'filter_order_line_item_subtotal' ),
			10,
			2
		);

		add_action(
			'connector_for_dk_after_update_meta_data',
			array( __CLASS__, 'import_user_discount_and_price_group' ),
			10,
			2
		);

		add_filter(
			'connector_for_dk_import_customer_include_properties',
			array( __CLASS__, 'add_discount_info_to_include_properties' ),
			10,
			1
		);

		add_filter(
			'manage_users_columns',
			array( __CLASS__, 'add_columns_to_users_table' ),
			10,
			1
		);

		add_filter(
			'manage_users_custom_column',
			array( __CLASS__, 'add_column_content_to_users_table' ),
			10,
			3
		);

		add_action(
			'show_user_profile',
			array( __CLASS__, 'display_discount_information_in_user_editor' ),
			10,
			1
		);

		add_action(
			'edit_user_profile',
			array( __CLASS__, 'display_discount_information_in_user_editor' ),
			10,
			1
		);

		add_action(
			'woocommerce_before_calculate_totals',
			array( __CLASS__, 'set_product_discounts_in_cart' ),
			20,
			1
		);

		add_action(
			'woocommerce_order_after_calculate_totals',
			array( __CLASS__, 'calculate_discount_totals_action' ),
			20,
			2
		);
	}

	/**
	 * Get the current customer
	 *
	 * @return WC_Customer The current customer.
	 */
	public static function get_current_customer(): WC_Customer {
		if (
			array_key_exists( 'connector_for_dk_current_customer', $GLOBALS ) &&
			$GLOBALS['connector_for_dk_current_customer'] instanceof WC_Customer
		) {
			return $GLOBALS['connector_for_dk_current_customer'];
		}

		$customer = new WC_Customer( get_current_user_id() );

		$GLOBALS['connector_for_dk_current_customer'] = $customer;

		return $customer;
	}

	/**
	 * Display information on a user's price group and discount in the user editor
	 *
	 * @param WP_User $profile_user The WP user who's profile is being edited.
	 */
	public static function display_discount_information_in_user_editor(
		WP_User $profile_user
	): void {
		$customer = new WC_Customer( $profile_user->ID );

		$GLOBALS['connector_for_dk_user_editor_price_group'] = intval(
			$customer->get_meta( 'connector_for_dk_price_group' )
		);

		$GLOBALS['connector_for_dk_user_editor_discount'] = floatval(
			$customer->get_meta( 'connector_for_dk_discount' )
		);

		require dirname( __DIR__ ) . '/views/user_discount_information.php';
	}

	/**
	 * Add price group and discount columns to the user table
	 *
	 * @param array $columns The current set of columns to filter.
	 */
	public static function add_columns_to_users_table(
		array $columns
	): array {
		if ( ! current_user_can( 'edit_users' ) ) {
			return $columns;
		}

		$array_offset = array_search( 'role', array_keys( $columns ), true );

		$discount_columns = array(
			'connector_for_dk_price_group' => __(
				'Price Group',
				'connector-for-dk'
			),
			'connector_for_dk_discount'    => __(
				'Discount',
				'connector-for-dk'
			),
		);

		return array_merge(
			array_slice( $columns, 0, $array_offset, true ),
			$discount_columns,
			array_slice( $columns, $array_offset, null, true )
		);
	}

	/**
	 * Add content to the price group and discount columns in the user table
	 *
	 * @param string $output The output to filter.
	 * @param string $column_name The column name/key.
	 * @param string $user_id The user's ID.
	 */
	public static function add_column_content_to_users_table(
		string $output,
		string $column_name,
		string $user_id
	): string {
		if ( $column_name === 'connector_for_dk_price_group' ) {
			$customer    = new WC_Customer( $user_id );
			$price_group = $customer->get_meta(
				'connector_for_dk_price_group'
			);

			if ( empty( $price_group ) ) {
				return '1';
			} else {
				return $price_group;
			}
		}

		if ( $column_name === 'connector_for_dk_discount' ) {
			$customer = new WC_Customer( $user_id );
			$discount = $customer->get_meta( 'connector_for_dk_discount' );

			return (string) floatval( $discount ) . '%';
		}

		return $output;
	}

	/**
	 * Replace the current product's price with the customer's discounted price
	 *
	 * Used in the `woocommerce_product_get_price` and
	 * `woocommerce_product_variation_get_price` filters.
	 *
	 * @param string     $price The original price.
	 * @param WC_Product $product The WooCommerce product.
	 */
	public static function price_to_customer_price(
		string $price,
		WC_Product $product
	): string {
		if ( is_admin() ) {
			return ( $price );
		}

		if ( $product->is_on_sale() ) {
			return $product->get_sale_price( 'edit' );
		}

		if ( empty( $product->get_price( 'edit' ) ) ) {
			return '';
		}

		$incl_tax = wc_prices_include_tax();

		$customer = self::get_current_customer();

		return ProductHelper::get_customer_price(
			$product,
			$customer,
			1,
			$incl_tax
		);
	}

	/**
	 * Replace the current product's price with the customer's group price
	 *
	 * @param string     $price The original price.
	 * @param WC_Product $product The WooCommerce product.
	 */
	public static function regular_price_to_group_price(
		string $price,
		WC_Product $product
	): string {
		if ( is_admin() ) {
			return ( $price );
		}

		if ( $product->is_on_sale( 'edit' ) ) {
			return $product->get_regular_price( 'edit' );
		}

		return self::get_product_group_price( $product );
	}

	/**
	 * Format a product's price as HTML
	 *
	 * Replaces the standard product price partial with our own, which is
	 * slightly different.
	 *
	 * @param string     $price The price partial to replace.
	 * @param WC_Product $product The product.
	 */
	public static function get_price_html(
		string $price,
		WC_Product $product
	): string {
		if ( ! ProductHelper::get_allow_discount( $product ) ) {
			return $price;
		}

		if ( $product instanceof WC_Product_Variable ) {
			return self::get_price_html_for_variable_product(
				$price,
				$product
			);
		}

		if ( $product->is_on_sale() ) {
			return wc_format_sale_price(
				wc_price( (float) $product->get_regular_price( 'edit' ) ),
				wc_price( (float) $product->get_sale_price( 'edit' ) )
			);
		}

		$incl_tax = get_option( 'woocommerce_tax_display_shop' ) === 'incl';

		$customer = self::get_current_customer();

		$regular_price = ProductHelper::get_group_price(
			$product,
			$customer,
			$incl_tax
		);

		$customer_price = ProductHelper::get_customer_price(
			$product,
			$customer,
			0,
			$incl_tax
		);

		if ( $regular_price === $customer_price ) {
			return wc_price( $customer_price );
		}

		return self::format(
			$regular_price,
			$customer_price
		);
	}

	/**
	 * Format a variable product's price range as HTML
	 *
	 * @param string     $price The price partial to replace.
	 * @param WC_Product $product The product.
	 */
	public static function get_price_html_for_variable_product(
		string $price,
		WC_Product $product
	): string {
		$incl_tax = get_option( 'woocommerce_tax_display_shop' ) === 'incl';
		$customer = new WC_Customer( get_current_user_id() );
		$prices   = ProductHelper::get_variation_prices(
			$product,
			$customer,
			$incl_tax
		);

		if ( $product->is_on_sale() ) {
			$regular_price_range = ProductHelper::get_customer_variable_price_range(
				$product,
				$customer,
				'price',
				$incl_tax,
				$prices
			);
			$current_price_range = ProductHelper::get_customer_variable_price_range(
				$product,
				$customer,
				'sale_price',
				$incl_tax,
				$prices
			);
		} else {
			$regular_price_range = ProductHelper::get_customer_variable_price_range(
				$product,
				$customer,
				'group_price',
				$incl_tax,
				$prices
			);
			$current_price_range = ProductHelper::get_customer_variable_price_range(
				$product,
				$customer,
				'customer_price',
				$incl_tax,
				$prices
			);
		}

		if ( $regular_price_range['min'] === $regular_price_range['max'] ) {
			$regular_price_range_string = wc_price( $regular_price_range['min'] );
		} else {
			$regular_price_range_string = wc_format_price_range(
				$regular_price_range['min'],
				$regular_price_range['max']
			);
		}

		if ( $current_price_range['min'] === $current_price_range['max'] ) {
			$current_price_range_string = wc_price( $current_price_range['min'] );
		} else {
			$current_price_range_string = wc_format_price_range(
				$current_price_range['min'],
				$current_price_range['max']
			);
		}

		return self::format(
			$regular_price_range_string,
			$current_price_range_string
		);
	}

	/**
	 * Add the required properties to the included customer properties
	 *
	 * This adds `Discount` and `PriceGroup` as the properties that are fetched
	 * when customer data is synced.
	 *
	 * This hooks into the `connector_for_dk_import_customer_include_properties`
	 * filter.
	 *
	 * @param array $properties The properties before filtering.
	 */
	public static function add_discount_info_to_include_properties(
		array $properties
	): array {
		$additional_keys = array( 'Discount', 'PriceGroup' );

		return array_merge( $properties, $additional_keys );
	}

	/**
	 * Fetch and save the a user's discount and price group based on DK data
	 *
	 * This hooks into `connector_for_dk_after_update_meta_data` during customer
	 * sync.
	 *
	 * @param WC_Customer $wc_customer The WooCommerce customer.
	 * @param object      $dk_customer An object representing the customer record in DK.
	 */
	public static function import_user_discount_and_price_group(
		WC_Customer $wc_customer,
		object $dk_customer
	): void {
		$wc_customer->update_meta_data(
			'connector_for_dk_discount',
			strval( $dk_customer->Discount )
		);

		$wc_customer->update_meta_data(
			'connector_for_dk_price_group',
			strval( $dk_customer->PriceGroup + 1 )
		);

		$wc_customer->save_meta_data();
	}

	/**
	 * Adapt the discounted price format to different themes
	 *
	 * This simply takes in the `connector_for_dk_customer_price_format` filter
	 * and applies changes to the output depending on the currently active
	 * theme.
	 *
	 * @param string $html The HTML snippet from the `format` function.
	 */
	public static function adapt_formatting_to_themes( string $html ): string {
		$current_theme = wp_get_theme();

		if ( $current_theme->get_stylesheet() === 'blocksy' ) {
			return "<span class=\"sale-price customer-price\">{$html}</span>";
		}

		return $html;
	}

	/**
	 * Filter cart items to display discounts
	 *
	 * Formats cart item prices to display them as discounted in the classic
	 * shortcode based checkout process.
	 *
	 * @param string $product_price The original product price string.
	 * @param array  $cart_item The item, as an associative array from WC()->cart.
	 *
	 * @return string A formatted string, with the original price struck-out if
	 *                there is a discount.
	 */
	public static function filter_cart_item_price(
		string $product_price,
		array $cart_item
	): string {
		$incl_tax = get_option( 'woocommerce_tax_display_cart' ) === 'incl';

		$original_price = $cart_item['data']->get_price( 'edit' );

		$discounted_price = self::get_current_customer_price(
			$cart_item['data'],
			(float) $cart_item['quantity'],
			$incl_tax
		);

		if ( $discounted_price === $original_price ) {
			return $product_price;
		}

		return self::format(
			$cart_item['data']->get_regular_price( 'edit' ),
			$discounted_price
		);
	}

	/**
	 * Format cart item subtotals to display discounts
	 *
	 * @param string $product_subtotal The subtotal string.
	 * @param array  $cart_item The item, as an associative array from WC()->cart.
	 *
	 * @return string A formatted string, with the original price struck-out if
	 *                there is a discount.
	 */
	public static function filter_cart_item_subtotal(
		string $product_subtotal,
		array $cart_item
	): string {
		$incl_tax = get_option( 'woocommerce_tax_display_cart' ) === 'incl';

		$original_price = $cart_item['data']->get_regular_price( 'edit' );

		$discounted_price = self::get_current_customer_price(
			product: $cart_item['data'],
			incl_tax: $incl_tax
		);

		if ( $discounted_price === $original_price ) {
			return $product_subtotal;
		}

		$original_subtotal = (string) BigDecimal::of(
			$original_price
		)->multipliedBy(
			$cart_item['quantity']
		)->toFloat();

		$discounted_subtotal = (string) BigDecimal::of(
			$discounted_price
		)->multipliedBy(
			$cart_item['quantity']
		)->toFloat();

		return self::format(
			$original_subtotal,
			$discounted_subtotal
		);
	}

	/**
	 * Display subtotals in the order confirmation as discounted
	 *
	 * @param string        $product_subtotal The originally displayed subtotal.
	 * @param WC_Order_Item $item The WooCommerce item.
	 */
	public static function filter_order_line_item_subtotal(
		string $product_subtotal,
		WC_Order_Item $item
	): string {
		if (
			$item instanceof WC_Order_Item_Product &&
			$item->get_product() &&
			$item->get_total() !== $item->get_subtotal()
		) {
			return self::format(
				(string) BigDecimal::of(
					$item->get_subtotal()
				)->plus(
					$item->get_subtotal_tax()
				)->toFloat(),
				(string) BigDecimal::of(
					$item->get_total()
				)->plus(
					$item->get_total_tax()
				)->toFloat()
			);
		}

		return $product_subtotal;
	}

	/**
	 * Get the product's group price for the currently logged-in customer
	 *
	 * This gets the group price before discount, which is then used as the
	 * "before" price.
	 *
	 * If the customer is not logged in, this will return the standard price of
	 * the product.
	 *
	 * @param WC_Product $product The product.
	 */
	private static function get_product_group_price(
		WC_Product $product
	): string {
		if ( is_admin() ) {
			return ( $product->get_price( 'edit' ) );
		}

		$customer = self::get_current_customer();

		if ( $customer->get_id() === 0 ) {
			return $product->get_price( 'edit' );
		}

		return ProductHelper::get_group_price(
			$product,
			$customer,
			wc_prices_include_tax()
		);
	}

	/**
	 * Get current user's product price
	 *
	 * Get the currently logged-in customer's unit price for a product, with
	 * product and customer's discount applied.
	 *
	 * @param WC_Product $product The product.
	 * @param int|float  $quantity The quantity, used for getting the unit
	 *                             price, with mass discount.
	 * @param bool       $incl_tax Wether or not to include tax in the amount.
	 */
	public static function get_current_customer_price(
		WC_Product $product,
		int|float $quantity = 1.0,
		bool $incl_tax = false
	): string {
		if ( is_admin() ) {
			return ( $product->get_regular_price( 'edit' ) );
		}

		if ( $product->is_on_sale( 'edit' ) ) {
			return $product->get_sale_price( 'edit' );
		}

		$customer = self::get_current_customer();

		return ProductHelper::get_customer_price(
			$product,
			$customer,
			$quantity,
			$incl_tax
		);
	}

	/**
	 * Format "before and after" prices when the customer has a discount
	 *
	 * @param string $regular_price The regular group price.
	 * @param string $customer_price The customer's price.
	 */
	private static function format(
		string $regular_price,
		string $customer_price
	): string {
		if ( is_numeric( $regular_price ) ) {
			$display_regular_price = wc_price( $regular_price, array() );
		} else {
			$display_regular_price = $regular_price;
		}

		if ( is_numeric( $customer_price ) ) {
			$display_customer_price = wc_price( $customer_price, array() );
		} else {
			$display_customer_price = $customer_price;
		}

		$html = "<span class='screen-reader-text'>" .
				__( 'Regular Price:', 'connector-for-dk' ) .
				'</span> ' .
				"<del>{$display_regular_price}</del> " .
				'<span class="screen-reader-text">' .
				__( 'Your Price:', 'connector-for-dk' ) .
				'</span> ' .
				"<ins>{$display_customer_price}</ins>";

		return apply_filters(
			'connector_for_dk_customer_price_format',
			$html,
			$regular_price,
			$customer_price
		);
	}

	/**
	 * Indicate product discounts in the WooCommerce cart
	 *
	 * Goes through the cart and faciliates displaying the original price and
	 * discounted price for discounted products. This is used both for customer
	 * discounts and product discounts.
	 *
	 * @param WC_Cart $cart The WooCommerce cart object.
	 */
	public static function set_product_discounts_in_cart(
		WC_Cart $cart
	): void {
		$customer = new WC_Customer( get_current_user_id() );
		$incl_tax = get_option( 'woocommerce_tax_display_cart' ) === 'incl';

		foreach ( $cart->get_cart_contents() as $cart_item ) {
			if ( ! $cart_item['data'] instanceof WC_Product ) {
				continue;
			}

			if ( ! is_array( $cart_item ) ) {
				continue;
			}

			if ( $cart_item['variation_id'] > 0 ) {
				$product = wc_get_product( $cart_item['variation_id'] );
			} else {
				$product = $cart_item['data'];
			}

			if ( ! ProductHelper::get_allow_discount( $product ) ) {
				continue;
			}

			$discount_quantity = ProductHelper::get_discount_quantity(
				$product
			);

			if ( $cart_item['quantity'] < $discount_quantity ) {
				continue;
			}

			$customer_price = (float) self::get_current_customer_price(
				$product,
				$cart_item['quantity'],
				$incl_tax
			);

			if ( $product->is_on_sale() ) {
				$regular_price = (float) $product->get_regular_price( 'edit' );
			} else {
				$regular_price = (float) ProductHelper::get_group_price(
					$product,
					$customer,
					$incl_tax
				);
			}

			$cart_item['data']->set_regular_price(
				(string) $regular_price
			);

			$cart_item['data']->set_price(
				(string) $regular_price
			);

			$cart_item['data']->set_sale_price(
				(string) $customer_price
			);
		}
	}

	/**
	 * Add the quantity discount indicator to the price display
	 *
	 * Used for hooking into woocommerce_get_price_html and appends the relevant
	 * HTML element to the price display block.
	 *
	 * @param string     $price The oirignal price string.
	 * @param WC_Product $product The product.
	 */
	public static function add_quantity_discount_to_price_display(
		string $price,
		WC_Product $product
	): string {
		$customer = self::get_current_customer();
		$text     = self::quantity_discount_indicator_text(
			$product,
			$customer
		);

		if ( empty( $text ) ) {
			return $price;
		}

		$css_class = implode(
			' ',
			apply_filters(
				'connector_for_dk_discount_indicator_css_classes',
				self::INDICATOR_CSS_CLASSES
			)
		);

		$html_element = apply_filters(
			'connector_for_dk_discount_indicator_html',
			"<p class=\"$css_class\">$text</p>",
			$price,
			$css_class,
			$text
		);

		return "$price\n$html_element";
	}

	/**
	 * The quantity discount indicator text
	 *
	 * Returns the contents of the quantity discount indicator displayed below a
	 * product's price if it has a minimum required quantity for a discount to
	 * apply.
	 *
	 * @param WC_Product  $product The product on display.
	 * @param WC_Customer $customer The customer the price is relevant to.
	 */
	public static function quantity_discount_indicator_text(
		WC_Product $product,
		WC_Customer $customer
	): string {
		if ( ProductHelper::has_price_override( $product ) ) {
			return '';
		}

		if ( ! ProductHelper::get_allow_discount( $product ) ) {
			return '';
		}

		$customer_discount = CustomerHelper::get_dk_discount( $customer );
		$product_discount  = ProductHelper::get_discount( $product );

		if ( (float) $customer_discount > (float) $product_discount ) {
			return '';
		}

		$discount_quantity = ProductHelper::get_discount_quantity( $product );

		if (
			(float) $product_discount === 0.0 ||
			(float) $discount_quantity === 0.0
		) {
			return '';
		}

		return apply_filters(
			'connector_for_dk_discount_indicator_text',
			sprintf(
				// Translators: %1$d is the percentage and %2$d is the minimum number of items for a discount.
				__( '%1$d%% discount for %2$d or more', 'connector-for-dk' ),
				$product_discount,
				$discount_quantity
			),
			$product_discount,
			$discount_quantity
		);
	}

	/**
	 * Calculate discount totals for an order and save to the order
	 *
	 * This is an improved version of the logic in the
	 * WC_Abstract_Order::calculate_totals method, which uses inprecise floating
	 * point maths and impropper rounding to calculate discount totals, when
	 * something like `BigDecimal` is a more appropriate tool for the job.
	 *
	 * In short, this prevents off-by-one errors in the discount calculations
	 * and discrepencies between discounts as shown in the cart and order
	 * confirmations, which are extremely common.
	 *
	 * @param WC_Order $order The order to recalculate discount totals for.
	 *
	 * @return object{success:bool,total:string,tax:string,grand_total:string}
	 */
	public static function calculate_discount_totals(
		WC_Order $order
	): object {
		$discount_total     = BigDecimal::of( 0 );
		$discount_total_tax = BigDecimal::of( 0 );

		foreach ( $order->get_items() as $item ) {
			if ( ! $item instanceof WC_Order_Item ) {
				continue;
			}

			switch ( get_class( $item ) ) {
				case 'WC_Order_Item_Product':
					$totals = self::get_discounts_for_order_item_product(
						$item
					);
					break;
				case 'WC_Order_Item_Coupon':
					$totals = self::get_discounts_for_order_item_coupon(
						$item
					);
					break;
				default:
					$totals = (object) array(
						'total' => '0',
						'tax'   => '0',
					);
					break;
			}

			$discount_total     = $discount_total->plus( $totals->total );
			$discount_total_tax = $discount_total_tax->plus( $totals->tax );
		}

		$grand_total = (string) round(
			BigDecimal::of(
				$discount_total
			)->plus(
				$discount_total_tax
			)->toFloat(),
			wc_get_price_decimals(),
			PHP_ROUND_HALF_UP
		);

		$order->set_discount_total( (string) $discount_total );
		$order->set_discount_tax( (string) $discount_total_tax );

		return (object) array(
			'success'     => $order->save(),
			'total'       => (string) $discount_total,
			'tax'         => (string) $discount_total_tax,
			'grand_total' => (string) $grand_total,
		);
	}

	/**
	 * Get discounts for order item product
	 *
	 * @param WC_Order_Item_Product $item The item to check.
	 *
	 * @return object{total:string,tax:string,grand_total:string}
	 */
	public static function get_discounts_for_order_item_product(
		WC_Order_Item_Product $item
	): object {
		$discount_total = BigDecimal::of(
			$item->get_subtotal()
		)->minus(
			$item->get_total()
		);

		$taxes = $item->get_taxes();

		$discount_total_tax = BigDecimal::of( 0 );

		foreach ( $taxes['subtotal'] as $tax ) {
			$discount_total_tax = $discount_total_tax->plus( $tax );
		}

		foreach ( $taxes['total'] as $tax ) {
			$discount_total_tax = $discount_total_tax->minus( $tax );
		}

		$grand_total = round(
			BigDecimal::of(
				$discount_total
			)->plus(
				$discount_total_tax
			)->toFloat(),
			wc_get_price_decimals(),
			PHP_ROUND_HALF_UP
		);

		return (object) array(
			'total'       => (string) $discount_total,
			'tax'         => (string) $discount_total_tax,
			'grand_total' => (string) $grand_total,
		);
	}

	/**
	 * Get discounts for an order coupon
	 *
	 * @param WC_Order_Item_Coupon $item The coupon item to check.
	 *
	 * @return object{total:string,tax:string,grand_total:string}
	 */
	private static function get_discounts_for_order_item_coupon(
		WC_Order_Item_Coupon $item
	): object {
		$grand_total = round(
			BigDecimal::of(
				$item->get_discount()
			)->plus(
				$item->get_discount_tax()
			)->toFloat(),
			wc_get_price_decimals(),
			PHP_ROUND_HALF_UP
		);

		return (object) array(
			'total'       => $item->get_discount(),
			'tax'         => $item->get_discount_tax(),
			'grand_total' => (string) $grand_total,
		);
	}

	/**
	 * Calculate discount totals (action wrapper)
	 *
	 * This is a wrapper for `calculate_discount_totals` used for hooking into
	 * `woocommerce_order_after_calculate_totals`.
	 *
	 * @param bool     $and_taxes Unused.
	 * @param WC_Order $order The WooCommerce order.
	 */
	public static function calculate_discount_totals_action(
		bool $and_taxes,
		WC_Order $order
	): object {
		return self::calculate_discount_totals( $order );
	}
}
