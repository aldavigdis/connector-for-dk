<?php

declare(strict_types = 1);

namespace AldaVigdis\ConnectorForDK\Export;

use AldaVigdis\ConnectorForDK\Config;
use AldaVigdis\ConnectorForDK\Export\Order as ExportOrder;
use AldaVigdis\ConnectorForDK\Export\Customer as ExportCustomer;
use AldaVigdis\ConnectorForDK\Helpers\Order as OrderHelper;
use AldaVigdis\ConnectorForDK\Service\DKApiRequest;
use WC_Order;
use WP_Error;
use AldaVigdis\ConnectorForDK\Brick\Math\BigDecimal;

/**
 * The Invoice Export class
 *
 * Facilitates the creation of invoices in DK from orders in
 * WooCommerce.
 */
class Invoice {
	const API_PATH = '/Sales/Invoice/';

	/**
	 * Create an invoice in DK based on A WooCommerce order
	 *
	 * @param WC_Order $wc_order The WooCommerce order.
	 * @param bool     $force Wether to force the creation of the invoice, even
	 *                        if it the order has been assigned with an invoice
	 *                        number from DK.
	 *
	 * @return string|false|WP_Error A string representing the invoice number
	 *                               from DK on success, false if connection was
	 *                               established but the request was rejected,
	 *                               WC_Error if there was a connection error.
	 */
	public static function create_in_dk(
		WC_Order $wc_order,
		bool $force = false
	): string|false|WP_Error {
		$kennitala = OrderHelper::get_kennitala( $wc_order );

		if ( ! $force ) {
			$invoice_number = self::get_dk_invoice_number( $wc_order );

			if ( ! empty( $invoice_number ) ) {
				return false;
			}
		}

		if (
			! OrderHelper::kennitala_is_default( $wc_order ) &&
			! ExportCustomer::is_in_dk( $kennitala )
		) {
			if ( ! ExportCustomer::create_in_dk_from_order( $wc_order ) ) {
				return false;
			}
		}

		$api_request  = new DKApiRequest();
		$request_body = self::to_dk_invoice_body( $wc_order );

		if ( ! $request_body ) {
			return false;
		}

		$result = $api_request->request_result(
			self::API_PATH,
			wp_json_encode( $request_body ),
		);

		if ( $result instanceof WP_Error ) {
			return $result;
		}

		if ( $result->response_code !== 200 ) {
			if ( property_exists( $result->data, 'Message' ) ) {
				$error_message = $result->data->Message;
			} else {
				$error_message = '';
			}
			return new WP_Error(
				'http_' . (string) $result->response_code,
				$error_message,
				$result->data
			);
		}

		if ( property_exists( $result->data, 'Number' ) ) {
			self::assign_dk_invoice_number(
				$wc_order,
				$result->data->Number
			);
			return (string) $result->data->Number;
		}

		return false;
	}

	/**
	 * Sends an invoice for an order to a customer via DK
	 *
	 * @param WC_Order $wc_order The WooCommerce order.
	 * @param string   $invoice_type The type of invoice. (Either debit or credit).
	 *
	 * @return bool|WP_Error True on success. False or WP_Error on failure.
	 */
	public static function email_in_dk(
		WC_Order $wc_order,
		string $invoice_type = 'debit'
	): bool|WP_Error {
		if (
			! in_array(
				$invoice_type,
				array( 'debit', 'credit' ),
				true
			)
		) {
			return false;
		}

		$to = $wc_order->get_billing_email();

		if ( empty( $to ) ) {
			return false;
		}

		$subject = sprintf(
			// Translators: The %1$s is a placeholder for the site's title.
			__( 'Your Invoice From %1$s', 'connector-for-dk' ),
			get_bloginfo( 'name' )
		);

		$request_body = array(
			'To'      => $to,
			'Subject' => $subject,
		);

		$api_request = new DKApiRequest();

		if ( $invoice_type === 'debit' ) {
			$invoice_number = self::get_dk_invoice_number( $wc_order );
		}

		if ( empty( $invoice_number ) ) {
			return false;
		}

		$result = $api_request->request_result(
			self::API_PATH . rawurlencode( $invoice_number ) . '/email',
			wp_json_encode( $request_body )
		);

		if ( $result instanceof WP_Error ) {
			return $result;
		}

		if ( $result->response_code !== 200 ) {
			return false;
		}

		if ( $result->response_code === 200 ) {
			return true;
		}

		return false;
	}

	/**
	 * Prepare a JSON POST body for creating a DK invoice
	 *
	 * @param WC_Order $wc_order The WooCommerce order.
	 *
	 * @return array|false An associative array representing the JSON request body. False on failure.
	 */
	public static function to_dk_invoice_body(
		WC_Order $wc_order,
	): array|false {
		$invoice_body = ExportOrder::to_dk_order_body( $wc_order );

		if ( ! $invoice_body ) {
			return false;
		}

		$invoice_body['SalesPerson'] = Config::get_default_sales_person_number();
		$invoice_body['Text2']       = $wc_order->get_customer_note( 'view' );

		$payment_mapping = Config::get_payment_mapping(
			$wc_order->get_payment_method()
		);

		if ( $wc_order->is_paid() && $payment_mapping->add_line ) {
			$total = BigDecimal::of(
				(string) $wc_order->get_total()
			)->minus(
				$wc_order->get_total_refunded()
			);

			$invoice_body['Payments'] = array(
				apply_filters(
					'connector_for_dk_invoice_payment_line',
					array(
						'ID'     => $payment_mapping->dk_id,
						'Name'   => $payment_mapping->dk_name,
						'Amount' => $total->toFloat(),
					),
					$payment_mapping,
					$wc_order
				),
			);
		}

		$invoice_body['Mode'] = apply_filters(
			'connector_for_dk_invoice_mode',
			$payment_mapping->dk_mode,
			$payment_mapping,
			$wc_order
		);

		$invoice_body['Term'] = apply_filters(
			'connector_for_dk_invoice_term',
			$payment_mapping->dk_term,
			$payment_mapping,
			$wc_order
		);

		return $invoice_body;
	}

	/**
	 * Assign a DK invoice number to a WooCommerce order
	 *
	 * @param WC_Order $wc_order The WooCommerce order.
	 * @param string   $dk_invoice_number The invoice number.
	 *
	 * @return string The invoice number.
	 */
	public static function assign_dk_invoice_number(
		WC_Order $wc_order,
		string $dk_invoice_number
	): string {
		$wc_order->update_meta_data(
			'connector_for_dk_invoice_number',
			$dk_invoice_number
		);

		$wc_order->save_meta_data();

		return $dk_invoice_number;
	}

	/**
	 * The the DK invoice number for an order based on metadata
	 *
	 * @param WC_Order $wc_order The WooCommerce order.
	 */
	public static function get_dk_invoice_number(
		WC_Order $wc_order
	): string {
		return (string) $wc_order->get_meta(
			'connector_for_dk_invoice_number'
		);
	}

	/**
	 * Check if an order has plausibly been invoiced in DK
	 *
	 * This checks if there is an invoice already in dk that corresponds to an
	 * order's ID, amount and customer.
	 *
	 * @param WC_Order $order The WooCommerce order.
	 */
	public static function is_plausibly_invoiced_in_dk(
		WC_Order $order
	): false|WP_Error|string {
		$api_request = new DKApiRequest();

		$order_reference = Config::get_invoice_reference_prefix() .
			(string) $order->get_id();

		$result = $api_request->get_result(
			self::API_PATH .
			'reference/' .
			$order_reference
		);

		if ( $result instanceof WP_Error ) {
			return $result;
		}

		if (
			! is_object( $result ) ||
			! is_array( $result->data ) ||
			empty( $result->data )
		) {
			return false;
		}

		$invoices = $result->data;

		usort(
			$invoices,
			function ( object $a, object $b ): int {
				$time_a = strtotime( $a->Created );
				$time_b = strtotime( $b->Created );

				if ( $time_a === $time_b ) {
					return 0;
				}

				return ( $time_a < $time_b ) ? 1 : -1;
			}
		);

		$last_invoice = array_first( $invoices );

		if (
			strtotime( (string) $last_invoice->Created ) <
			strtotime( (string) $order->get_date_created() )
		) {
			return false;
		}

		if (
			(float) $last_invoice->TotalAmountWithTax !==
			(float) $order->get_total()
		) {
			return false;
		}

		if (
			(string) $last_invoice->CNumber !==
			OrderHelper::get_kennitala( $order )
		) {
			return false;
		}

		return (string) $last_invoice->Number;
	}
}
