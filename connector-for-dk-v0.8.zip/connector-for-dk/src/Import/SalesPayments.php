<?php

declare(strict_types = 1);

namespace AldaVigdis\ConnectorForDK\Import;

use AldaVigdis\ConnectorForDK\Service\DKApiRequest;
use AldaVigdis\ConnectorForDK\Config;
use WP_Error;

/**
 * The SalesPayments class
 *
 * Provides funtions for handling downstream payment methods from DK
 */
class SalesPayments {
	const TRANSIENT_EXPIRY = 15 * MINUTE_IN_SECONDS;
	const REQUEST_TIMEOUT  = 5;

	const DK_PAYMENT_MODES = array(
		'ABG',
		'BM',
		'CG',
		'GKR',
		'GM',
		'IB',
		'STGR',
		'TGR',
	);

	const DK_PAYMENT_TERMS = array(
		'D15',
		'D20',
		'D30',
		'LM',
		'M15',
		'M20',
		'POST',
		'STGR',
	);

	/**
	 * Get payment terms from the DK API
	 */
	public static function get_payment_terms_from_dk(): array|WP_Error|false {
		$request = new DKApiRequest();
		$result  = $request->get_result(
			'/general/table/ARPTERM.DAT/records?legacy=true&fields=CODE,DESCRIPTION',
			self::REQUEST_TIMEOUT
		);

		if ( $result instanceof WP_Error ) {
			return $result;
		}

		if ( $result->response_code !== 200 ) {
			return false;
		}

		return $result->data;
	}

	/**
	 * Get the name of a payment term from key
	 *
	 * @param string $key The payment term key from DK_PAYMENT_TERMS.
	 *
	 * @return string A "translated" name for the key, or just the key itself if
	 *                it is not defined in DK_PAYMENT_TERMS.
	 */
	public static function get_payment_term_name( string $key ): string {
		switch ( $key ) {
			case 'D15':
				return __( '15 Day Payment Deadline (D15)', 'connector-for-dk' );
			case 'D20':
				return __( '20 Day Payment Deadline (D20)', 'connector-for-dk' );
			case 'D30':
				return __( '30 Day Payment Deadline (D30)', 'connector-for-dk' );
			case 'LM':
				return __( 'Current Month (LM)', 'connector-for-dk' );
			case 'M15':
				return __( 'Current Month + 15 Days (M15)', 'connector-for-dk' );
			case 'M20':
				return __( 'Current Month + 20 Days (M20)', 'connector-for-dk' );
			case 'POST':
				return __( 'Postal COD (POST)', 'connector-for-dk' );
			case 'STGR':
				return __( 'Cash Payment (STGR)', 'connector-for-dk' );
		}

		return $key;
	}

	/**
	 * Get payment term codes
	 *
	 * If the API key has been set, returns the payment term codes from the
	 * relevant database table in DK.
	 *
	 * If the API key has not been set, or if there is a connection error, the
	 * contents of DK_PAYMENT_TERMS will be returned.
	 *
	 * @return array<string>
	 */
	public static function get_payment_terms(): array {
		$terms_updated = get_option(
			'connector_for_dk_payment_terms_updated',
			0
		);

		$terms_transient = get_option(
			'connector_for_dk_payment_terms',
			false
		);

		if (
			is_array( $terms_transient ) &&
			( $terms_updated > time() - self::TRANSIENT_EXPIRY )
		) {
			return $terms_transient;
		}

		if ( is_string( Config::get_dk_api_key() ) ) {
			$terms = self::get_payment_terms_from_dk();

			if ( is_array( $terms ) ) {
				$plucked_terms = array_column( $terms, 'CODE' );

				update_option(
					'connector_for_dk_payment_terms_updated',
					time()
				);

				update_option(
					'connector_for_dk_payment_terms',
					$plucked_terms,
				);

				return $plucked_terms;
			}
		}

		if ( ! $terms_transient ) {
			return array();
		}

		return $terms_transient;
	}

	/**
	 * Get payment modes form the DK API
	 *
	 * @return array<string>
	 */
	public static function get_payment_modes_from_dk(): array|WP_Error|false {
		$request = new DKApiRequest();
		$result  = $request->get_result(
			'/general/table/ARPMODE.DAT/records?legacy=true&fields=CODE,DESCRIPTION',
			self::REQUEST_TIMEOUT
		);

		if ( $result instanceof WP_Error ) {
			return $result;
		}

		if ( $result->response_code !== 200 ) {
			return false;
		}

		return $result->data;
	}

	/**
	 * Get the name of a payment mode from key
	 *
	 * @param string $key The payment mode key from DK_PAYMENT_MODES.
	 *
	 * @return string The full name of the payment mode. If the key is not
	 *                defined in DK_PAYMENT_MODES, only the key itself is
	 *                returned.
	 */
	public static function get_payment_mode_name( string $key ): string {
		switch ( $key ) {
			case 'ABG':
				return __( 'A or B Giro Request (ABG)', 'connector-for-dk' );
			case 'BM':
				return __( 'Bank Transfer (BM)', 'connector-for-dk' );
			case 'CG':
				return __( 'C Giro Request (CG)', 'connector-for-dk' );
			case 'GKR':
				return __( 'Card Payment (GKR)', 'connector-for-dk' );
			case 'GM':
				return __( 'Giro Transfer (GM)', 'connector-for-dk' );
			case 'IB':
				return __( 'Bank Collection Service (IB)', 'connector-for-dk' );
			case 'STGR':
				return __( 'Cash Payment (STGR)', 'connector-for-dk' );
			case 'TGR':
				return __( 'Cheque Payment (TGR)', 'connector-for-dk' );
		}

		return $key;
	}

	/**
	 * Get payment modes
	 *
	 * If the API key has been set, returns the payment mode codes from the
	 * relevant database table in DK.
	 *
	 * If the API has not been set, or if there is a connection error, the
	 * contents of DK_PAYMENT_MODES will be returned.
	 */
	public static function get_payment_modes(): array {
		$modes_updated = get_option(
			'connector_for_dk_payment_modes_updated',
			0
		);

		$modes_transient = get_option(
			'connector_for_dk_payment_modes',
			false
		);

		if (
			is_array( $modes_transient ) &&
			( $modes_updated > time() - self::TRANSIENT_EXPIRY )
		) {
			return $modes_transient;
		}

		if ( is_string( Config::get_dk_api_key() ) ) {
			$modes = self::get_payment_modes_from_dk();

			if ( is_array( $modes ) ) {
				$plucked_modes = array_column( $modes, 'CODE' );

				update_option(
					'connector_for_dk_payment_modes_updated',
					time()
				);

				update_option(
					'connector_for_dk_payment_modes',
					$plucked_modes
				);

				return $plucked_modes;
			}
		}

		if ( ! $modes_transient ) {
			return self::DK_PAYMENT_MODES;
		}

		return (array) $modes_transient;
	}

	/**
	 * Get payment methods
	 *
	 * Uses a transient to cache the results from the DK API for 24 hours.
	 *
	 * @return array<object>
	 */
	public static function get_methods(): array {
		$methods_updated = get_option(
			'connector_for_dk_payment_methods_updated',
			0
		);

		$methods_transient = get_option(
			'connector_for_dk_payment_methods',
			false
		);

		if (
			is_array( $methods_transient ) &&
			( $methods_updated > time() - self::TRANSIENT_EXPIRY )
		) {
			return $methods_transient;
		}

		if ( is_string( Config::get_dk_api_key() ) ) {
			$methods = self::get_methods_from_dk();

			if ( is_array( $methods ) ) {
				update_option(
					'connector_for_dk_payment_methods',
					$methods
				);
				update_option(
					'connector_for_dk_payment_methods_updated',
					time()
				);

				return $methods;
			}
		}

		if ( ! $methods_transient ) {
			return array();
		}

		return $methods_transient;
	}

	/**
	 * Get payment methods from the DK API, bypassing the transient cache
	 *
	 * @return array<object>
	 */
	public static function get_methods_from_dk(): array|WP_Error|false {
		$request = new DKApiRequest();
		$result  = $request->get_result(
			'/Sales/Payment/Type?include=PaymentId%2CName%2CActive',
			self::REQUEST_TIMEOUT
		);

		if ( $result instanceof WP_Error ) {
			return $result;
		}

		if ( $result->response_code !== 200 ) {
			return false;
		}

		return self::convert_json_response_for_methods( $result->data );
	}

	/**
	 * Find a payment method by ID
	 *
	 * Finds a payment method by its value in DK.
	 *
	 * @param int $id The DK payment method ID.
	 */
	public static function find_by_id( int $id ): object|false {
		foreach ( self::get_methods() as $method ) {
			if ( $id === $method->dk_id ) {
				return $method;
			}
		}

		return false;
	}

	/**
	 * Clean and order the JSON response from the DK API
	 *
	 * @param array $json_response The already-decoded JSON data as it comes
	 *                             from the API.
	 *
	 * @return array<object>
	 */
	public static function convert_json_response_for_methods(
		array $json_response
	): array {
		$methods = array();

		foreach ( $json_response as $method ) {
			$methods[] = (object) array(
				'dk_id'     => $method->PaymentId,
				'dk_name'   => $method->Name,
				'dk_active' => $method->Active,
			);
		}

		usort(
			$methods,
			function ( $a, $b ) {
				if ( $a > $b ) {
					return 1;
				}
				return -1;
			}
		);

		return $methods;
	}
}
