<?php

declare(strict_types = 1);

namespace AldaVigdis\ConnectorForDK;

use AldaVigdis\ConnectorForDK\Import\Products as ImportProducts;
use AldaVigdis\ConnectorForDK\Config;
use WC_Product;
use WC_Product_Variable;
use WC_Product_Variation;

/**
 * The WooMetaboxes class
 *
 * The WooMetaboxes class adds fields to the WooCommerce editor metaboxes that
 * handle properties facilitating price and inventory sync with DK.
 */
class Metaboxes {
	const PROTECTED_META = array(
		'connector_for_dk_invoice_attempts',
		'connector_for_dk_price_sync',
		'connector_for_dk_stock_sync',
		'connector_for_dk_name_sync',
		'connector_for_dk_dk_currency',
		'connector_for_dk_credit_invoice_number',
		'connector_for_dk_invoice_number',
		'last_downstream_sync',
		'connector_for_dk_price_sync',
		'connector_for_dk_stock_sync',
		'connector_for_dk_name_sync',
		'connector_for_dk_currency',
		'connector_for_dk_credit_invoice_number',
		'connector_for_dk_invoice_number',
		'connector_for_dk_last_downstream_sync',
		'connector_for_dk_price_group',
		'connector_for_dk_version',
		'connector_for_dk_pdf_file_name',
		'connector_for_dk_customer_discount',
	);

	/**
	 * The constructor for the WooMetaboxes class
	 */
	public function __construct() {
		if ( Config::get_dk_api_key() ) {
			add_action(
				'woocommerce_update_product',
				array( $this, 'save_product_meta' ),
				10,
				2
			);

			add_filter(
				'is_protected_meta',
				array( __CLASS__, 'protect_meta' ),
				10,
				2
			);

			add_filter(
				'woocommerce_product_data_tabs',
				array( __CLASS__, 'remove_variations_from_product_editor' ),
				98,
				1
			);

			add_action(
				'woocommerce_product_data_panels',
				array( __CLASS__, 'variations_panel' )
			);

			add_action( 'init', array( __CLASS__, 'add_image_sizes' ) );

			add_filter(
				'woocommerce_product_data_tabs',
				array( __CLASS__, 'add_product_data_tab' ),
				98
			);

			add_action(
				'woocommerce_product_data_panels',
				array( __CLASS__, 'dk_connection_panel' ),
			);
		}
	}

	/**
	 * Add the "DK Sync" tab to the product data box
	 *
	 * @see https://woocommerce.github.io/code-reference/files/woocommerce-includes-admin-meta-boxes-class-wc-meta-box-product-data.html#source-view.76
	 *
	 * @param array $tabs The tabs array to filter.
	 */
	public static function add_product_data_tab( array $tabs ): array {
		$tabs['dk_connection'] = array(
			'label'    => __( 'DK Sync', 'connector-for-dk' ),
			'target'   => 'dk_connection_product_tab',
			'class'    => array( 'hide_if_grouped' ),
			'priority' => 100,
		);

		return $tabs;
	}

	/**
	 * Render the "DK Sync" panel content
	 */
	public static function dk_connection_panel(): void {
		require dirname( __DIR__ ) . '/views/dk_connection_product_panel.php';
	}

	/**
	 * Addd the image sizes used by the plugin
	 *
	 * 400px with is 2x the with of the thumbnail we use in the variation
	 * editor, accounting for high resolution displays.
	 */
	public static function add_image_sizes(): void {
		add_image_size( 'connector_for_dk_variant', 400 );
	}

	/**
	 * Remove the default WooCommerce variations UI from the product meta tabs
	 *
	 * As we are relying on DK's variant products feature, we replace the
	 * WooCommerce product variations interface with our own, which is primarily
	 * read-only.
	 *
	 * This replaces our previous approach, which was to trust users to
	 * manipulate product variations in WooCommerce, which may conflict with
	 * DK's variation feature. This was assumed to be an acceptable approach
	 * before we realised that DK supported variations, but that the feature had
	 * to be enabled by DK's support as it is not on by default.
	 *
	 * @param array $tabs The tabs array to be filtered.
	 */
	public static function remove_variations_from_product_editor(
		array $tabs
	): array {
		$wc_product = wc_get_product();

		if ( $wc_product->get_meta( 'connector_for_dk_origin' ) !== 'product_variation' ) {
			return $tabs;
		}

		unset( $tabs['variations'] );

		$tabs['attribute']['class'] = array( 'hide_if_variable' );

		$tabs['connector_for_dk_variations'] = array(
			'label'    => __( 'DK Variations', 'connector-for-dk' ),
			'target'   => 'dk_variations_tab',
			'priority' => 60,
			'class'    => array( 'show_if_variable' ),
		);

		return $tabs;
	}

	/**
	 * Render the DK variations panel
	 */
	public static function variations_panel(): void {
		require dirname( __DIR__ ) . '/views/dk_product_variations.php';
	}

	/**
	 * Protect the meta values so they don't appear in the Custom Fields box
	 *
	 * This prevents the kennitala value from appearing in the Custom Fields
	 * metabox, overriding the order editor.
	 *
	 * @param bool   $protected Wether the meta value is already protected.
	 * @param string $meta_key The meta key.
	 */
	public static function protect_meta(
		bool $protected,
		string $meta_key
	): bool {
		if ( in_array( $meta_key, self::PROTECTED_META, true ) ) {
			return true;
		}

		return $protected;
	}

	/**
	 * Save the ConnectorForDK related meta tags for a product using superglobals
	 *
	 * Fired during the `save_post_product` hook.
	 *
	 * @param int        $id The post ID for the product.
	 * @param WC_Product $wc_product The post object (unused).
	 */
	public function save_product_meta(
		int $id,
		WC_Product $wc_product
	): void {
		// As the hook seems to be run twice for some reason, this should
		// prevent the function to run twice during the same HTTP request.
		if ( defined( '1984_DK_WOO_META_UPDATE_HAS_RUN' ) ) {
			return;
		}

		define( '1984_DK_WOO_META_UPDATE_HAS_RUN', true );

		self::set_product_sync_meta_from_post( $wc_product, 'price' );
		self::set_product_sync_meta_from_post( $wc_product, 'stock' );
		self::set_product_sync_meta_from_post( $wc_product, 'name' );

		if ( is_a( $wc_product, 'WC_Product_Variable' ) ) {
			self::set_product_variation_meta_from_post( $wc_product );
		}
	}

	/**
	 * Set a product sync meta value from a POST superglobal
	 *
	 * Checks the relevant nonces and sets the `connector_for_dk_` product meta from
	 * a $_POST superglobal.
	 *
	 * @param WC_Product $wc_product The WooCommerce product.
	 * @param string     $meta_key The relevant meta key such as price, stock or name.
	 */
	public static function set_product_sync_meta_from_post(
		WC_Product $wc_product,
		string $meta_key
	): void {
		$nonce_superglobal = "set_connector_for_dk_{$meta_key}_sync_nonce";
		$wc_meta_key       = "connector_for_dk_{$meta_key}_sync";

		if (
			! empty( $_POST[ $nonce_superglobal ] ) &&
			wp_verify_nonce(
				sanitize_text_field(
					wp_unslash( $_POST[ $nonce_superglobal ] )
				),
				"set_connector_for_dk_{$meta_key}_sync"
			)
		) {
			if ( isset( $_POST[ $wc_meta_key ] ) ) {
				switch ( $_POST[ $wc_meta_key ] ) {
					case 'true':
						$wc_product->update_meta_data( $wc_meta_key, 'true' );
						break;
					case 'false':
						$wc_product->update_meta_data( $wc_meta_key, 'false' );
						break;
					default:
						$wc_product->update_meta_data( $wc_meta_key, '' );
				}

				$wc_product->save_meta_data();
			}
		}
	}

	/**
	 * Save information about the product variations from the POST superglobal
	 *
	 * Checks the relevant nonce and sets the relevant status and other
	 * attributes for the variable product's variations.
	 *
	 * @param WC_Product_Variable $wc_product The WooCommerce product.
	 */
	private static function set_product_variation_meta_from_post(
		WC_Product_Variable $wc_product
	): void {
		if (
			! empty( $_POST['connector_for_dk_variations_nonce'] ) &&
			wp_verify_nonce(
				sanitize_text_field(
					wp_unslash( $_POST['connector_for_dk_variations_nonce'] )
				),
				'connector_for_dk_variations'
			)
		) {
			if ( $wc_product->get_meta( 'connector_for_dk_origin' ) !== 'product_variation' ) {
				return;
			}

			self::set_default_attributes_via_post( $wc_product );

			foreach ( $wc_product->get_children() as $variation_id ) {
				$variation = wc_get_product( $variation_id );

				if ( $variation->get_meta( 'connector_for_dk_origin' ) === 'product' ) {
					continue;
				}

				if ( $variation === false ) {
					continue;
				}

				if ( isset( $_POST['dk_variable_enabled'][ $variation_id ] ) ) {
					if ( $variation->get_status( 'edit' ) !== 'publish' ) {
						$variation->set_status( 'publish' );
					}
				} else {
					if ( $variation->get_status( 'edit' ) !== 'private' ) {
						$variation->set_status( 'private' );
					}
				}

				$variation->set_downloadable(
					isset( $_POST['dk_variable_is_downloadable'][ $variation_id ] )
				);

				$variation->set_virtual(
					isset( $_POST['dk_variable_is_virtual'][ $variation_id ] )
				);

				if ( isset( $_POST['dk_variable_description'][ $variation_id ] ) ) {
					$variation->set_description(
						sanitize_text_field(
							wp_unslash(
								$_POST['dk_variable_description'][ $variation_id ]
							)
						)
					);
				}

				if ( isset( $_POST['dk_variable_price_override'][ $variation_id ] ) ) {
					$variation->update_meta_data(
						'connector_for_dk_variable_price_override',
						1
					);

					self::set_variation_prices_via_post( $variation );
				} else {
					self::reset_variation_price( $variation );
				}

				if ( isset( $_POST['dk_variable_inventory_override'][ $variation_id ] ) ) {
					$variation->update_meta_data(
						'connector_for_dk_variable_inventory_override',
						'true'
					);

					if (
						isset( $_POST['dk_variable_quantity_track_in_wc'][ $variation_id ] ) &&
						isset( $_POST['dk_variable_quantity'][ $variation_id ] ) &&
						isset( $_POST['dk_variable_override_allow_backorders_in_wc'][ $variation_id ] )
					) {
						$variation->update_meta_data(
							'connector_for_dk_variable_quantity_track_in_wc',
							'true'
						);

						self::set_varation_inventory_via_post( $variation );
					} else {
						self::reset_variation_stock( $variation );
					}
				} else {
					self::reset_variation_stock( $variation );
				}

				if ( isset( $_POST['dk_variable_image_id'][ $variation_id ] ) ) {
					$variation->set_image_id(
						intval(
							sanitize_text_field(
								wp_unslash(
									$_POST['dk_variable_image_id'][ $variation_id ]
								)
							)
						)
					);
				}

				self::set_variant_menu_order_via_post( $variation );

				$variation->save();
			}
		}
	}

	/**
	 * Reset the prices for a WooCommerce product variation
	 *
	 * Sets the variant price back to the main DK price of the product and
	 * enables price sync for the variant again.
	 *
	 * @param WC_Product_Variation $variation The WooCommerce product variation.
	 */
	private static function reset_variation_price(
		WC_Product_Variation $variation
	): void {
		$variation->delete_meta_data(
			'connector_for_dk_variable_price_override',
		);

		$parent = wc_get_product( $variation->get_parent_id() );

		$price = $parent->get_meta( 'connector_for_dk_price' );

		if ( is_object( $price ) ) {
			$variation->set_regular_price( $price->price );
			$variation->set_sale_price( $price->sale_price );
			$variation->set_date_on_sale_from( $price->date_on_sale_from );
			$variation->set_date_on_sale_to( $price->date_on_sale_to );

			$variation->save();
		}
	}

	/**
	 * Reset the stock quantity and inventory for product variation
	 *
	 * Sets the variant quantity to back to what is defined in DK and enbales
	 * quantity sync for the variant.
	 *
	 * @param WC_Product_Variation $variation The WooCommerce product variation.
	 */
	private static function reset_variation_stock(
		WC_Product_Variation $variation,
	): void {
		$parent = wc_get_product( $variation->get_parent_id() );

		$variation->delete_meta_data( 'connector_for_dk_variable_inventory_override' );
		$variation->delete_meta_data( 'connector_for_dk_variable_quantity_track_in_wc' );

		$variation->set_manage_stock( $parent->get_manage_stock() );
		$variation->set_backorders( $parent->get_backorders() );

		$product_json = json_decode(
			$parent->get_meta( 'connector_for_dk_product_json' )
		);

		$variation->set_stock_quantity(
			ImportProducts::get_variation_quantity_from_json(
				$product_json,
				array_values( $variation->get_attributes() )
			)
		);

		$variation->save();
	}

	/**
	 * Set the default product attributes via the $_POST superglobal
	 *
	 * Checks the nonce value and sets the default variation for a product via
	 * $_POST['dk_variable_defaults'].
	 *
	 * @param WC_Product_Variable $wc_product The WooCommerce product.
	 */
	private static function set_default_attributes_via_post(
		WC_Product_Variable $wc_product
	): void {
		if (
			! isset( $_POST['connector_for_dk_variations_nonce'] ) ||
			! wp_verify_nonce(
				sanitize_text_field(
					wp_unslash( $_POST['connector_for_dk_variations_nonce'] )
				),
				'connector_for_dk_variations'
			) ||
			! isset( $_POST['dk_variable_defaults'] )
		) {
			return;
		}

		$variation_attributes = array_keys( $wc_product->get_variation_attributes() );
		$variation_defaults   = array();

		foreach ( $variation_attributes as $attribute ) {
			if (
				isset( $_POST['dk_variable_defaults'][ $attribute ] ) &&
				is_string( $_POST['dk_variable_defaults'][ $attribute ] )
			) {
				$variation_defaults[ $attribute ] = sanitize_text_field(
					wp_unslash(
						$_POST['dk_variable_defaults'][ $attribute ]
					)
				);
			}
		}

		$wc_product->set_default_attributes( $variation_defaults );

		$wc_product->save();
	}

	/**
	 * Set the price of a product variant using the $_POST superglobal
	 *
	 * Sets the regular price, sale price and sale dates for a product variant
	 * using the relevant $_POST attributes.
	 *
	 * @param WC_Product_Variation $variation The product variation.
	 */
	private static function set_variation_prices_via_post(
		WC_Product_Variation $variation
	): void {
		if (
			! isset( $_POST['connector_for_dk_variations_nonce'] ) ||
			! wp_verify_nonce(
				sanitize_text_field(
					wp_unslash( $_POST['connector_for_dk_variations_nonce'] )
				),
				'connector_for_dk_variations'
			)
		) {
			return;
		}

		if ( isset( $_POST['dk_variable_price'][ $variation->get_id() ] ) ) {
			$variation->set_regular_price(
				sanitize_text_field(
					wp_unslash(
						$_POST['dk_variable_price'][ $variation->get_id() ]
					)
				)
			);
		}
		if ( isset( $_POST['dk_variable_sale_price'][ $variation->get_id() ] ) ) {
			$variation->set_sale_price(
				sanitize_text_field(
					wp_unslash(
						$_POST['dk_variable_sale_price'][ $variation->get_id() ]
					)
				)
			);
		}
		if ( isset( $_POST['dk_variable_on_sale_from'][ $variation->get_id() ] ) ) {
			if ( empty( $_POST['dk_variable_on_sale_from'][ $variation->get_id() ] ) ) {
				$variation->set_date_on_sale_from( null );
			} else {
				$variation->set_date_on_sale_from(
					sanitize_text_field(
						wp_unslash(
							$_POST['dk_variable_on_sale_from'][ $variation->get_id() ]
						)
					)
				);
			}
		}

		if ( isset( $_POST['dk_variable_on_sale_to'][ $variation->get_id() ] ) ) {
			if ( empty( $_POST['dk_variable_on_sale_to'][ $variation->get_id() ] ) ) {
				$variation->set_date_on_sale_to( null );
			} else {
				$variation->set_date_on_sale_to(
					sanitize_text_field(
						wp_unslash(
							$_POST['dk_variable_on_sale_to'][ $variation->get_id() ]
						)
					)
				);
			}
		}
	}

	/**
	 * Set the inventory attributes of a product variation via the $_POST superglobal
	 *
	 * @param WC_Product_Variation $variation The variation.
	 */
	private static function set_varation_inventory_via_post(
		WC_Product_Variation $variation
	): void {
		if (
			! isset( $_POST['connector_for_dk_variations_nonce'] ) ||
			! wp_verify_nonce(
				sanitize_text_field(
					wp_unslash( $_POST['connector_for_dk_variations_nonce'] )
				),
				'connector_for_dk_variations'
			)
		) {
			return;
		}

		$variation->set_manage_stock( true );

		if ( isset( $_POST['dk_variable_quantity'][ $variation->get_id() ] ) ) {
			$variation->set_stock_quantity(
				(float) sanitize_text_field(
					wp_unslash(
						$_POST['dk_variable_quantity'][ $variation->get_id() ]
					)
				)
			);
		}

		if ( isset( $_POST['dk_variable_override_allow_backorders_in_wc'][ $variation->get_id() ] ) ) {
			$variation->set_backorders(
				sanitize_text_field(
					wp_unslash(
						$_POST['dk_variable_override_allow_backorders_in_wc'][ $variation->get_id() ]
					)
				)
			);
		}
	}

	/**
	 * Set the menu order of a variant using the $_POST superglobal
	 *
	 * @param WC_Product_Variation $variation The variation.
	 */
	private static function set_variant_menu_order_via_post(
		WC_Product_Variation $variation
	): void {
		if (
			! isset( $_POST['connector_for_dk_variations_nonce'] ) ||
			! wp_verify_nonce(
				sanitize_text_field(
					wp_unslash( $_POST['connector_for_dk_variations_nonce'] )
				),
				'connector_for_dk_variations'
			)
		) {
			return;
		}

		if ( isset( $_POST['dk_variable_menu_order'][ $variation->get_id() ] ) ) {
			$variation->set_menu_order(
				(int) sanitize_text_field(
					wp_unslash(
						$_POST['dk_variable_menu_order'][ $variation->get_id() ]
					)
				)
			);
		}
	}
}
